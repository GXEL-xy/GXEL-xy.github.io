#!/usr/bin/env bash
# ============================================================
# 项目 H · 开工前体检（对应《K8s项目H_ArgoCD_GitOps实战.md》§0.6 + §4.2.1）
#
# 用法（在 master 11.0.1.128 上）：
#     bash h-preflight.sh
#
# 产物：
#     ./h-baseline-<时间戳>/preflight.log        完整输出（可直接贴给 AI）
#     ./h-baseline-<时间戳>/helm-values.yaml     接管前的生产开关（★ 阶段 5 对账基准）
#     ./h-baseline-<时间戳>/resources-before.yaml 接管前的对象快照
#
# 设计原则：
#   ① 只读：不改集群任何配置（唯一的临时动作是出网探测 Pod，跑完即删）
#   ② 逐项容错：某项失败不影响后面继续检查
#   ③ 输出可复现：所有关键状态落盘，阶段 5 做完同步后拿它逐项对账
# ============================================================

# 防御：如果文件被 Windows 编辑过（CRLF 行尾），自动转换后重新执行
if grep -qaU $'\r' "$0" 2>/dev/null; then
  sed -i 's/\r$//' "$0"
  exec bash "$0" "$@"
fi

TS=$(date +%Y%m%d-%H%M)
DIR="./h-baseline-$TS"
mkdir -p "$DIR"
LOG="$DIR/preflight.log"
: > "$LOG"

PASS=0; FAIL=0; WARN=0

log(){ echo "$@" | tee -a "$LOG"; }
ok(){  PASS=$((PASS+1)); log "  [ OK ] $1"; }
bad(){ FAIL=$((FAIL+1)); log "  [FAIL] $1"; }
wrn(){ WARN=$((WARN+1)); log "  [WARN] $1"; }
sec(){ log ""; log "============================================================"; log "$1"; log "============================================================"; }
run(){ log "\$ $*"; "$@" 2>&1 | tee -a "$LOG"; }

log "项目 H 开工体检 —— $(date '+%Y-%m-%d %H:%M:%S')"
log "基线目录：$DIR"

# ------------------------------------------------------------
sec "1/8  集群与节点"
# ------------------------------------------------------------
if kubectl cluster-info >/dev/null 2>&1; then
  ok "kubectl 可访问集群"
  run kubectl get nodes -o wide
  NOTREADY=$(kubectl get nodes --no-headers 2>/dev/null | awk '$2!="Ready"' | wc -l)
  [ "$NOTREADY" -eq 0 ] && ok "3 个节点全部 Ready" || bad "$NOTREADY 个节点不是 Ready"
else
  bad "kubectl 无法访问集群 —— 后面的检查都会失败，先修这一步"
  log ""
  log ">>> 体检中断：集群不可达。"
  exit 1
fi

# ------------------------------------------------------------
sec "2/8  业务现状（GitOps 接管前的基线）"
# ------------------------------------------------------------
kubectl get ns damo-app >/dev/null 2>&1 && ok "命名空间 damo-app 存在" || bad "命名空间 damo-app 不存在"

log ""; log "--- helm release ---"
helm list -n damo-app 2>&1 | tee -a "$LOG"

log ""; log "--- Deployment / Pods ---"
kubectl -n damo-app get deploy -o wide 2>&1 | tee -a "$LOG"
kubectl -n damo-app get pods -o wide 2>&1 | tee -a "$LOG"

REPLICAS=$(kubectl -n damo-app get deploy damo-app -o jsonpath='{.spec.replicas}' 2>/dev/null)
[ -n "$REPLICAS" ] && log "当前 Deployment.spec.replicas = $REPLICAS"

log ""; log "--- 业务可用性（打有 Pod 的节点，不是 128！）---"
for ip in 11.0.1.129 11.0.1.130; do
  R=$(curl -s --noproxy '*' --max-time 5 "http://$ip:30090/" 2>/dev/null | grep -o 'Build #[0-9]*')
  [ -n "$R" ] && { log "  $ip:30090 → $R"; BUILD="$R"; }
done
[ -n "$BUILD" ] && ok "业务可访问（$BUILD）" || wrn "两个 worker 的 30090 都没响应 —— 先确认 Pod 在哪、Service 是否 externalTrafficPolicy: Local"

# ------------------------------------------------------------
sec "3/8  ★ 生产开关基线（本项目最关键的检查）"
# ------------------------------------------------------------
if helm -n damo-app get values damo-app > "$DIR/helm-values.yaml" 2>/dev/null; then
  ok "已保存 helm values 基线 → $DIR/helm-values.yaml"
  log ""; log "--- 当前生效的 values（重点看下面两个开关）---"
  cat "$DIR/helm-values.yaml" | tee -a "$LOG"

  V=$(cat "$DIR/helm-values.yaml")
  echo "$V" | grep -A2 '^autoscaling:' | grep -q 'enabled: *true' \
    && ok "autoscaling.enabled = true（HPA 生效）" \
    || bad "autoscaling.enabled 不是 true → 项目 G 的 HPA 可能没生效"
  echo "$V" | grep -A2 '^networkPolicy:' | grep -q 'enabled: *true' \
    && ok "networkPolicy.enabled = true（项目 F 的加固生效）" \
    || bad "networkPolicy.enabled 不是 true → 项目 F 的加固可能没生效"
else
  wrn "读不到 helm values —— release 可能改名或已删（不影响开工，但接管时就少了对照基准）"
fi

log ""; log "--- HPA ---"
kubectl -n damo-app get hpa 2>&1 | tee -a "$LOG"
HPA_N=$(kubectl -n damo-app get hpa --no-headers 2>/dev/null | wc -l)
[ "$HPA_N" -ge 1 ] && ok "有 $HPA_N 个 HPA（项目 G 成果在线）" || wrn "没有 HPA —— 项目 G 的成果不在，6.5 的演示会做不了"

log ""; log "--- NetworkPolicy ---"
kubectl -n damo-app get netpol 2>&1 | tee -a "$LOG"
NP_N=$(kubectl -n damo-app get netpol --no-headers 2>/dev/null | wc -l)
[ "$NP_N" -ge 1 ] && ok "有 $NP_N 条 NetworkPolicy（项目 F 成果在线）" || wrn "没有 NetworkPolicy —— 项目 F 的成果不在"

log ""
log "★★ 记住上面这两个数字：HPA=$HPA_N，NETPOL=$NP_N"
log "   阶段 5 同步完成后必须【一个不少】。少一个就说明 valueFiles 漏了 values-prod.yaml（见 §4.2.1）"

# 落一份对象快照，供阶段 5 对比
kubectl -n damo-app get deploy,svc,netpol,hpa -o yaml > "$DIR/resources-before.yaml" 2>/dev/null \
  && ok "对象快照已保存 → $DIR/resources-before.yaml"

# ------------------------------------------------------------
sec "4/8  项目 F 的压测负载是否已清理"
# ------------------------------------------------------------
if kubectl -n damo-app get deploy loadgen >/dev/null 2>&1; then
  LG=$(kubectl -n damo-app get deploy loadgen -o jsonpath='{.spec.replicas}/{.status.readyReplicas}' 2>/dev/null)
  log "  loadgen replicas/ready = $LG"
  case "$LG" in
    0/*|"0/") ok "loadgen 已缩到 0（不影响接管）" ;;
    *) wrn "loadgen 仍在跑（$LG）—— 建议先 kubectl -n damo-app scale deploy loadgen --replicas=0，避免干扰演示" ;;
  esac
else
  ok "loadgen 不存在（已清理）"
fi

# ------------------------------------------------------------
sec "5/8  NodePort 30400 是否空闲"
# ------------------------------------------------------------
USED=$(kubectl get svc -A -o custom-columns='NS:.metadata.namespace,NAME:.metadata.name,NP:.spec.ports[*].nodePort' --no-headers 2>/dev/null | grep -w '30400')
if [ -z "$USED" ]; then
  ok "30400 空闲，可给 argocd-server 用"
else
  bad "30400 已被占用：$USED —— 换一个端口（同步改 manifests 与文档）"
fi
log ""; log "--- 现有 NodePort 全景（对照端口规划）---"
kubectl get svc -A -o custom-columns='NS:.metadata.namespace,NAME:.metadata.name,TYPE:.spec.type,NP:.spec.ports[*].nodePort' --no-headers 2>/dev/null \
  | awk '$3=="NodePort"' | sort -k4 | tee -a "$LOG"

# ------------------------------------------------------------
sec "6/8  节点资源余量（Argo CD 约 500m CPU / 1Gi 内存）"
# ------------------------------------------------------------
if kubectl top nodes 2>/dev/null | tee -a "$LOG" | grep -q '%'; then
  ok "metrics-server 正常（kubectl top 可用）"
  HIGH=$(kubectl top nodes --no-headers 2>/dev/null | awk '{gsub("%","",$3); if ($3+0 > 70) print $1"("$3")"}')
  [ -z "$HIGH" ] && ok "CPU 使用率均在 70% 以下" || wrn "CPU 偏高的节点：$HIGH（仍可安装，但要关注 argocd-repo-server 的 requests）"
else
  wrn "kubectl top 不可用 —— metrics-server 没就绪（项目 G 的依赖，同时会导致 HPA 的 TARGETS 显示 unknown）"
fi
log ""; log "--- 磁盘（镜像中转需要空间）---"
df -h /var/lib/containerd /var/lib/docker 2>/dev/null | tee -a "$LOG"

# ------------------------------------------------------------
sec "7/8  ★ 集群出网 GitHub（pull 模型的生命线）"
# ------------------------------------------------------------
log "--- 节点侧（master 的 curl，可能走代理，仅供参考）---"
NODE_CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 12 \
  https://raw.githubusercontent.com/GXEL-xy/damo-app/main/chart/damo-app/Chart.yaml 2>/dev/null)
case "$NODE_CODE" in
  200) ok "master 能访问 GitHub raw（HTTP $NODE_CODE）" ;;
  000) wrn "master curl 失败（可能是代理/网络限制，集群 Pod 侧另测）" ;;
  *)   wrn "master 访问 GitHub raw 返回 HTTP $NODE_CODE" ;;
esac

log ""
log "--- ★ Pod 侧（这才是 repo-server 的真实视角，不走宿主代理）---"
log "启动临时 Pod 探测（default 命名空间，避开项目 F 的 NetworkPolicy）..."
log "★ 不用 kubectl run -i --rm：超时会连 Pod 一起删掉，证据消失（实测踩过）"
kubectl run h-netcheck --image=11.0.1.128:30000/busybox:1.36 --restart=Never \
  --command -- sleep 600 >/dev/null 2>&1

if kubectl wait --for=condition=Ready pod/h-netcheck --timeout=90s >/dev/null 2>&1; then
  PROBE=$(kubectl exec h-netcheck -- sh -c \
    'nslookup github.com >/dev/null 2>&1 && echo DNS_OK || echo DNS_FAIL;
     nc -z -w 8 github.com 443 >/dev/null 2>&1 && echo TCP443_OK || echo TCP443_FAIL' 2>/dev/null)
  log "$PROBE"
  echo "$PROBE" | grep -q DNS_OK    && ok "Pod 内 DNS 解析正常"      || bad "Pod 内 DNS 解析失败（CoreDNS 问题，Argo CD 拉不了 Git）"
  echo "$PROBE" | grep -q TCP443_OK && ok "Pod 能出网访问 github.com:443" || bad "Pod 出不了网 —— Argo CD 的 pull 模型会直接失败，必须先解决出口"
else
  bad "临时 Pod 90 秒内没 Ready —— 多半是镜像 11.0.1.128:30000/busybox:1.36 拉不到"
  log "--- describe 尾部（定位根因）---"
  kubectl describe pod h-netcheck 2>&1 | tail -18 | tee -a "$LOG"
  log "若确认仓库里没有该镜像，先中转："
  log "  sudo docker pull --platform linux/amd64 busybox:1.36 && sudo docker tag busybox:1.36 11.0.1.128:30000/busybox:1.36 && sudo docker push 11.0.1.128:30000/busybox:1.36"
fi
kubectl delete pod h-netcheck --wait=false >/dev/null 2>&1

# ------------------------------------------------------------
sec "8/8  私有仓库：Argo CD 镜像是否已中转 / 业务镜像 tag"
# ------------------------------------------------------------
CATALOG=$(curl -s --noproxy '*' --max-time 8 http://11.0.1.128:30000/v2/_catalog 2>/dev/null)
if [ -n "$CATALOG" ]; then
  ok "私有仓库可访问"
  for repo in argocd redis dex; do
    if echo "$CATALOG" | grep -q "\"$repo\""; then
      ok "镜像 $repo 已在私有仓库（阶段 2 可跳过它）"
    else
      log "  [ .. ] 镜像 $repo 尚未中转（阶段 2 需要做）"
    fi
  done
else
  wrn "读不到私有仓库 catalog（可能开了认证，或 curl 走了代理）"
fi

log ""
log "--- damo-app 的 tag 列表（Application 里的 image.tag 必须在这里面）---"
curl -s --noproxy '*' --max-time 8 http://11.0.1.128:30000/v2/damo-app/tags/list 2>/dev/null | tee -a "$LOG"

# ------------------------------------------------------------
sec "体检结论"
# ------------------------------------------------------------
log "  通过 $PASS 项 / 警告 $WARN 项 / 失败 $FAIL 项"
log ""
if [ "$FAIL" -eq 0 ]; then
  log "  ✅ 无阻塞项，可以进入阶段 2（镜像中转）。"
else
  log "  ⛔ 有 $FAIL 项失败，先解决再往下走："
  log "     · 集群不可达 → 启动三台 VM，确认 ssh 11.0.1.128 能通"
  log "     · Pod 出网失败 → Argo CD 无法拉 Git，这是项目 H 的硬前置"
  log "     · 30400 被占用 → 换端口（同步改 manifests/argocd-server-nodeport.md）"
fi
log ""
log "  基线已存到：$DIR/"
log "  ★ 阶段 5 同步完成后，用这份基线逐项对账（尤其 HPA / NetworkPolicy 数量）。"
log ""
log "  下一步：把 preflight.log 贴回给 AI，或直接开始 §阶段 2 镜像中转。"
