# 项目 H · Argo CD 安装前置：镜像中转 + `install.yaml` 改写步骤清单

> **本文档对应实战文档 §2.1–2.3**。延续项目 B 的**镜像中转铁律**：
> **master 上 docker 拉 → tag → push 到私有仓库 → 各节点 containerd 从私有仓库拉取。**
> Argo CD 的三个镜像来自 **三个不同的上游仓库**（quay.io / public.ecr.aws / ghcr.io）——
> 这正是中转铁律的价值所在：**节点只需要认识一个私有仓库，上游有几个源、能不能直连都不重要。**

---

## 步骤 1：下载官方 `install.yaml`（不要凭记忆列镜像）

```bash
# 在 master 上
mkdir -p ~/argocd-install && cd ~/argocd-install
curl -LO https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
```

> ⚠️ 若 master 直连 GitHub 不稳，可在**能上网的机器**（如 Windows）下载后 `scp` 到 master。

## 步骤 2：从清单里「提取」镜像列表（★ 方法论，别跳过）

```bash
grep -E '^\s+image:' install.yaml | sed 's/.*image: *//' | tr -d '"' | sort -u
```

**预期输出（形如，实际版本以你下载到的为准）**：

```
ghcr.io/dexidp/dex:v2.x.x
public.ecr.aws/docker/library/redis:7.x-alpine
quay.io/argoproj/argocd:v2.x.x
```

> **★ 为什么这么做**：**不凭记忆写版本号，而是让清单告诉你需要什么** ——
> 官方升级、新增组件时，这个方法不会漏。面试被问「你怎么知道要中转哪些镜像」，
> 这个回答比背清单更有说服力。

## 步骤 3：逐个中转（`docker pull → tag → push`）

```bash
# 在 master 上执行（docker 已配代理；★ 需要 sudo，见下方注意）
REGISTRY=11.0.1.128:30000
MS=                                          # （此变量与 metrics-server 无关，勿混用）

# ① argocd 本体（版本以步骤 2 提取到的为准）
sudo docker pull quay.io/argoproj/argocd:v2.13.0
sudo docker tag  quay.io/argoproj/argocd:v2.13.0 ${REGISTRY}/argocd:v2.13.0
sudo docker push ${REGISTRY}/argocd:v2.13.0

# ② redis
sudo docker pull public.ecr.aws/docker/library/redis:7.2-alpine
sudo docker tag  public.ecr.aws/docker/library/redis:7.2-alpine ${REGISTRY}/redis:7.2-alpine
sudo docker push ${REGISTRY}/redis:7.2-alpine

# ③ dex（若决定保留 dex；纯 admin 登录可跳过并删掉对应 Deployment）
sudo docker pull ghcr.io/dexidp/dex:v2.41.1
sudo docker tag  ghcr.io/dexidp/dex:v2.41.1 ${REGISTRY}/dex:v2.41.1
sudo docker push ${REGISTRY}/dex:v2.41.1

# ④ 验证私有仓库里三个镜像都在
curl -s http://11.0.1.128:30000/v2/_catalog | tr ',' '\n' | grep -E 'argocd|redis|dex'
```

### ★ 注意两条（项目 G 实测踩过）

1. **需要 `sudo`**：master 上普通用户不在 `docker` 组
   （报错 `permission denied ... /var/run/docker.sock`）。
   一劳永逸：`sudo usermod -aG docker $USER` 后重新登录。
2. **`docker pull` 走的是 daemon 的代理**（`/etc/systemd/system/docker.service.d/*.conf`），
   与 `sudo` 无关；但 `~/.docker/config.json` 的 `proxies` **只作用于 build/run**，不影响 pull。

### 兜底方案（某镜像拉不动时，要会走这条路）

GitHub Container Registry（ghcr.io）在国内经常不稳。拉不动时：

```bash
# 在能上网的机器上
docker pull ghcr.io/dexidp/dex:v2.41.1
docker save ghcr.io/dexidp/dex:v2.41.1 -o dex.tar
scp dex.tar wddf@11.0.1.128:~

# 在 master 上
sudo docker load -i ~/dex.tar
sudo docker tag  ghcr.io/dexidp/dex:v2.41.1 11.0.1.128:30000/dex:v2.41.1
sudo docker push 11.0.1.128:30000/dex:v2.41.1
```

## 步骤 4：改写 `install.yaml` 的镜像地址（3 条 sed + 双向核对）

```bash
cd ~/argocd-install

# 先备份
cp install.yaml install.yaml.orig

# 三条替换
sed -i 's|quay.io/argoproj/argocd:|11.0.1.128:30000/argocd:|g' install.yaml
sed -i 's|public.ecr.aws/docker/library/redis:|11.0.1.128:30000/redis:|g' install.yaml
sed -i 's|ghcr.io/dexidp/dex:|11.0.1.128:30000/dex:|g' install.yaml

# ★ 正向核对：应全部指向私有仓库
grep -E '^\s+image:' install.yaml | sed 's/.*image: *//' | tr -d '"' | sort -u
# 期望：三行，全部以 11.0.1.128:30000/ 开头

# ★ 反向核对：不应有上游仓库地址残留
grep -cE 'quay\.io|public\.ecr\.aws|ghcr\.io' install.yaml
# 期望：0
```

## 完成后的下一步

→ 回实战文档 **§3.1**：`kubectl create ns argocd` →
→ **`kubectl apply --server-side=true --force-conflicts -n argocd -f install.yaml`**
→ （★ 必须加 `--server-side=true`：否则 `applicationsets.argoproj.io` 这个 CRD 会因
→   `last-applied-configuration` 注解超过 256KB 被拒，见实战文档 §3.1 的专门说明）→
→ 再做 **NodePort 30400**（见同目录 `../manifests/argocd-server-nodeport.md`）。
