# 项目 H · 把 `argocd-server` 暴露成 NodePort 30400

> **本文档对应实战文档 §3.2**。Argo CD 装好后，UI 默认只有 ClusterIP，
> 外部访问不了 —— 这里把它暴露成 NodePort `30400`（端口规划见项目 C 的端口表，避免冲突）。

---

## 一、两种方式与取舍

| 方式 | 说明 | 取舍 |
|---|---|---|
| **方式一：`kubectl patch`**（本项目采用） | 一条命令直接把 Service 改成 NodePort | ✅ 快、不依赖额外组件；❌ **这个状态不在 Git 里** |
| **方式二：写进 Git 让 Argo CD 自己管** | 把 Service 定义放进 Git 目录（Helm/Kustomize），让 Argo CD 管自己的 Service（"自举 / bootstrap"） | ✅ 状态进 Git、可审计；❌ 属"自举"话题，**为控制复杂度本项目不用** |

> **取舍记录（面试可讲）**：「方式二更"GitOps 正统"，但要把 Argo CD 自己也纳入 Git 管理
> （自举），会引入一层间接。**本项目为了控制复杂度选方式一**，并把这条取舍写进文档 ——
> **知道"正统做法是什么、为什么暂时不用"本身也是工程判断的一部分。**」

---

## 二、方式一：patch（复制粘贴即可）

```bash
kubectl -n argocd patch svc argocd-server -p '{
  "spec": {
    "type": "NodePort",
    "ports": [
      {"name":"http","port":80,"protocol":"TCP","targetPort":8080},
      {"name":"https","port":443,"protocol":"TCP","targetPort":8080,"nodePort":30400}
    ]
  }
}'
```

## 三、验证

```bash
kubectl -n argocd get svc argocd-server
# 期望：TYPE = NodePort，PORTS 里有 443:30400/TCP

# 外部可达性（★ 注意是 HTTPS，证书自签 → 用 -k 跳过校验）
curl -sk -o /dev/null -w '%{http_code}\n' https://11.0.1.128:30400/
# 期望：200 或 404（都说明服务起来了）
```

---

## ★★ 一个反直觉的坑（很容易写错）

> **Argo CD 的 `argocd-server` 容器【只有一个端口：8080】** ——
> 它**同时支持 HTTP 和 HTTPS**（由它自己判断收到的流量是哪种）。

所以 Service 的写法是：

| Service 的 `port` | `targetPort` | 说明 |
|---|---|---|
| 80 | **8080** | 不是 80→80 |
| 443（nodePort 30400） | **8080** | ★ **不是 443→443** |

**如果写成 `targetPort: 443`，连接会被直接拒绝** —— 因为容器里根本没人监听 443。
（这是 Argo CD 与大多数"HTTP/HTTPS 分开监听"的服务不一样的地方。）

---

## 回退

```bash
# 把 Service 改回 ClusterIP（恢复默认）
kubectl -n argocd patch svc argocd-server -p '{"spec":{"type":"ClusterIP","ports":[{"port":80,"targetPort":8080}]}}'
```

> 注意：`kubectl patch` 出来的状态**不在 Git 里** —— 如果集群重建/重装 Argo CD，
> 需要重跑本文档的 patch 命令。这也是"方式二"被推荐的原因。
