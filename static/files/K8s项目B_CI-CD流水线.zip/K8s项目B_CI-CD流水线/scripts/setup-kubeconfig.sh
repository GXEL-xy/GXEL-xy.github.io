#!/bin/bash
# ============================================================
# 生成 Jenkins Agent 用的 kubeconfig 并存入 Secret（master 节点执行）
# 用法：bash scripts/setup-kubeconfig.sh
# ============================================================
set -e

echo "==> 生成 kubeconfig（server 改为集群内访问地址）"
kubectl config view --raw --minify | \
  sed 's|server:.*|server: https://kubernetes.default.svc.cluster.local:443|' \
  > kubeconfig-jenkins

echo "==> 检查生成的 server 地址"
grep "server:" kubeconfig-jenkins

echo "==> 存入 Secret（jenkins 命名空间）"
kubectl create secret generic kubeconfig -n jenkins \
  --from-file=config=kubeconfig-jenkins --dry-run=client -o yaml | kubectl apply -f -

rm -f kubeconfig-jenkins
echo "✅ kubeconfig Secret 已就绪（kubectl 容器将自动挂载到 /root/.kube/config）"
