#!/bin/bash
# ============================================================
# 项目B 一键部署脚本（在 master 节点执行）
# 作用：应用 registry + jenkins 全部清单，并等待就绪
# 用法：bash scripts/deploy.sh
# ============================================================
set -e
cd "$(dirname "$0")/.."

echo "==> [1/4] 部署私有仓库 registry"
kubectl apply -f manifests/registry.yaml

echo "==> [2/4] 部署 Jenkins"
kubectl apply -f manifests/jenkins.yaml

echo "==> [3/4] 等待 registry 就绪"
kubectl rollout status deployment/registry -n registry --timeout=120s

echo "==> [4/4] 等待 Jenkins 就绪（首次拉镜像较慢）"
kubectl rollout status deployment/jenkins -n jenkins --timeout=600s

echo ""
echo "✅ 部署完成！"
echo "   registry API:  curl http://11.0.1.128:30000/v2/  （应返回 {}）"
echo "   Jenkins 登录:  http://11.0.1.128:30080/"
echo "   初始密码:      kubectl exec -it deploy/jenkins -n jenkins -- cat /var/jenkins_home/secrets/initialAdminPassword"
echo ""
echo "接下来请按主文档操作："
echo "   1. 三节点 containerd 配置私有仓库信任（主文档 2.3）"
echo "   2. kubeconfig 凭据（bash scripts/setup-kubeconfig.sh）"
echo "   3. Jenkins UI 配置 Cloud / PodTemplate（主文档 4 阶段）"
