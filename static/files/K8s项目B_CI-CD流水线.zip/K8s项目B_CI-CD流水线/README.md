# K8s 项目 B：CI/CD 流水线 —— 项目文件包

> 主文档（详细步骤/排障/自测题/面试要点）：`../K8s项目B_CI-CD流水线实战.md`
> 本目录把所有 YAML、源码、脚本落成真实文件，可直接拷到集群 master 使用。

## 目录结构

```
K8s项目B_CI-CD流水线/
├── README.md                          ← 本文件
├── manifests/                         ← K8s 清单（阶段 2、3）
│   ├── registry.yaml                  ← 私有仓库：Namespace + PVC + Deployment + Service(NodePort 30000)
│   └── jenkins.yaml                   ← Jenkins：Namespace + SA + RBAC + PVC + Deployment + Service(30080/31000)
├── damo-app/                          ← GitHub 仓库源码（阶段 1，直接 push）
│   ├── index.html                     ← 静态页（构建号占位符 __BUILD_NUMBER__）
│   ├── Dockerfile                     ← nginx alpine 镜像定义
│   ├── Jenkinsfile                    ← 流水线定义（Checkout→渲染→Kaniko构建→部署→验证）
│   └── k8s/
│       ├── deployment.yaml            ← Deployment（image 占位符 __IMAGE__，由流水线替换）
│       └── service.yaml               ← Service NodePort 30090
└── scripts/                           ← 辅助脚本（master 节点执行）
    ├── deploy.sh                      ← 一键部署 registry + jenkins
    └── setup-kubeconfig.sh            ← 生成 Agent kubeconfig 并存 Secret
```

## 快速开始（对应主文档阶段）

| 步骤 | 操作 | 主文档 |
|------|------|--------|
| 1. 源码入库 | `cd damo-app && git init && git add . && git commit -m "init" && git push` | 阶段 1 |
| 2. 部署 registry | `kubectl apply -f manifests/registry.yaml` | 阶段 2 |
| 3. containerd 信任 | 三节点改 `/etc/containerd/config.toml`（见主文档 2.3） | 阶段 2 |
| 4. 部署 Jenkins | `kubectl apply -f manifests/jenkins.yaml`（或 `bash scripts/deploy.sh`） | 阶段 3 |
| 5. 初始化 Jenkins | 浏览器 `http://11.0.1.128:30080/`，装插件、建账号 | 阶段 3 |
| 6. kubeconfig 凭据 | `bash scripts/setup-kubeconfig.sh` | 阶段 4 |
| 7. 配置 Cloud/Agent | Jenkins UI：Cloud + PodTemplate（jnlp/kaniko/kubectl） | 阶段 4 |
| 8. 建流水线 Job | Pipeline from SCM，仓库 `https://github.com/GXEL-xy/damo-app.git` | 阶段 5 |
| 9. 验证 | 改 index.html push → 自动构建部署 → `curl http://11.0.1.128:30090/` | 阶段 6 |

## 环境参数（已确认）

| 参数 | 值 |
|------|-----|
| master IP | 11.0.1.128 |
| GitHub 仓库 | https://github.com/GXEL-xy/damo-app.git |
| 集群版本 | v1.35（containerd / Ubuntu 24.04） |
| 端口 | registry 30000 · Jenkins 30080 · damo-app 30090 |

## 关键提醒

- Agent 容器 Working directory 必须留空，Jenkinsfile 全部用相对路径（`--context .`）
- 三节点 containerd 都要配 registry mirrors，否则 Pod 调度到 worker 会 ImagePullBackOff
- 构建用 Kaniko 不用 docker：kubelet 运行时是 containerd，docker 构建的镜像集群看不见
- 详细排障见主文档第 7 节
