# K8s 项目 C：监控告警（Prometheus + Grafana + Alertmanager）

3 节点集群监控体系：节点指标 + K8s 对象指标 + 可视化大屏 + QQ 邮箱真实告警闭环。

## 快速开始（master 上执行）

```bash
# 0. 改占位符（必须！）
#   manifests/05-prometheus.yaml  和 06-grafana.yaml 里的 __NODE_NAME__ → 固定节点名（建议 work1）
#   manifests/07-alertmanager-config.yaml 里的 __SMTP_AUTH_CODE__ → QQ 邮箱 SMTP 授权码
kubectl get nodes   # 查节点名

# 1. 镜像中转（国内网络预案，5 个镜像进私有仓库）
bash scripts/pull-images.sh

# 2. 按编号顺序部署
kubectl apply -f manifests/00-namespace.yaml
kubectl apply -f manifests/01-node-exporter.yaml
kubectl apply -f manifests/02-kube-state-metrics.yaml
kubectl apply -f manifests/03-prometheus-rbac.yaml
kubectl apply -f manifests/04-prometheus-config.yaml
kubectl apply -f manifests/05-prometheus.yaml
kubectl apply -f manifests/06-grafana.yaml
kubectl apply -f manifests/07-alertmanager-config.yaml
kubectl apply -f manifests/08-alertmanager.yaml

# 3. 一键验证
bash scripts/verify.sh
```

## 访问入口

| 服务 | 地址 | 账号 |
|------|------|------|
| Prometheus | http://11.0.1.128:30091 | 无（Status→Targets 看采集状态） |
| Grafana | http://11.0.1.128:30300 | admin / Grafana@2026 |
| Alertmanager | http://11.0.1.128:30093 | 无 |

## 部署后两个必做动作

1. **Grafana 加数据源**：Connections → Data sources → Prometheus → URL 填 `http://prometheus.monitoring.svc.cluster.local:9090` → Save & test
2. **导入仪表盘**：Dashboards → Import → 输入 `1860` → 数据源选 prometheus（Load 失败走离线 JSON，见主文档 6.4）

## 告警闭环测试

```bash
# 删一个 node-exporter 触发 NodeDown（1 分钟后 QQ 邮箱收 FIRING，恢复收 RESOLVED）
kubectl delete pod -n monitoring $(kubectl get pods -n monitoring -l app=node-exporter -o wide | grep work2 | awk '{print $1}')
```

## 详细教学

看主文档：`../K8s项目C_监控告警实战.md`（原理讲解 / 逐字段说明 / 排错表 / 自测题 / 面试要点）
