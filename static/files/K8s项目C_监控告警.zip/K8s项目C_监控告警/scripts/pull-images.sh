#!/bin/bash
# ============================================================
# 项目 C 前置：把 5 个监控镜像中转进私有仓库（国内网络预案）
# 在 master 上执行: bash scripts/pull-images.sh
# 原理: master 的 docker 走代理能访问外网仓库，
#       拉下来打 tag 推进 11.0.1.128:30000，所有节点内网秒拉
# ============================================================
set -e

REG="11.0.1.128:30000"

# 原始镜像清单（版本为写文档时验证过的稳定版）
IMAGES=(
  "quay.io/prometheus/node-exporter:v1.8.2"
  "registry.k8s.io/kube-state-metrics/kube-state-metrics:v2.13.0"
  "prom/prometheus:v2.53.1"
  "grafana/grafana:11.1.0"
  "prom/alertmanager:v0.27.0"
)

for IMG in "${IMAGES[@]}"; do
  # 取 "最后一段" 作为私有仓库名，如 prom/prometheus:v2.53.1 -> prometheus:v2.53.1
  NAME="${IMG##*/}"
  echo "==> [1/3] pull  $IMG"
  docker pull "$IMG"
  echo "==> [2/3] tag   $REG/$NAME"
  docker tag "$IMG" "$REG/$NAME"
  echo "==> [3/3] push  $REG/$NAME"
  docker push "$REG/$NAME"
done

echo ""
echo "✅ 全部中转完成，私有仓库当前监控镜像:"
curl -s "http://$REG/v2/_catalog" | python3 -m json.tool 2>/dev/null || curl -s "http://$REG/v2/_catalog"
