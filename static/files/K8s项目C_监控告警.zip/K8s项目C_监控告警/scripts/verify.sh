#!/bin/bash
# ============================================================
# 项目 C 部署后一键验证脚本
# 在 master 上执行: bash scripts/verify.sh
# ============================================================

echo "========== 1. 全部 Pod 状态 =========="
kubectl get pods -n monitoring -o wide

echo ""
echo "========== 2. node-exporter 数量（应 = 节点数 3）=========="
kubectl get ds node-exporter -n monitoring \
  -o jsonpath='{.status.numberReady}{" / 期望 "}{.status.desiredNumberScheduled}{"\n"}'

echo ""
echo "========== 3. Prometheus Web (30091) =========="
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://11.0.1.128:30091/-/healthy

echo ""
echo "========== 4. Grafana Web (30300) =========="
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://11.0.1.128:30300/api/health

echo ""
echo "========== 5. Alertmanager Web (30093) =========="
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://11.0.1.128:30093/-/healthy

echo ""
echo "========== 6. 手动检查清单 =========="
echo "[ ] 浏览器打开 http://11.0.1.128:30091/targets —— 应全绿（3 个 node-exporter + prometheus + kube-state-metrics）"
echo "[ ] 浏览器打开 http://11.0.1.128:30091/alerts —— 应能看到 5 条告警规则（无 firing 属正常）"
echo "[ ] 浏览器打开 http://11.0.1.128:30300 —— admin / Grafana@2026 登录"
echo "[ ] Grafana 添加数据源: http://prometheus.monitoring.svc.cluster.local:9090"
echo "[ ] 导入仪表盘 1860（Node Exporter Full），出图即为成功"
