#!/usr/bin/env bash
# ============================================================
# 项目 F · 安全加固验收脚本
#
# 用法：bash manifests/verify-hardening.sh
# 说明：只读检查，不修改集群任何状态，可反复运行
# 适用：K8s v1.35 三节点集群（master 11.0.1.128 / work1 / work2）
#       命名空间 damo-app，私有仓库 11.0.1.128:30000
#
# 设计原则：每项检查都输出"期望值 vs 实际值"，便于快速定位回退
# ============================================================
set -uo pipefail

NS=damo-app
DEPLOYER=system:serviceaccount:damo-app:damo-deployer-sa
APP_URL=http://11.0.1.128:30090/
BUSYBOX=11.0.1.128:30000/busybox:1.36

POD=$(kubectl -n "$NS" get pod -l app.kubernetes.io/name=damo-app \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)

pass=0; fail=0
chk() { # chk "描述" "期望" "实际"
  if [ "$2" = "$3" ]; then
    echo "  ✅ $1"; pass=$((pass+1))
  else
    echo "  ❌ $1  (期望=$2 实际=$3)"; fail=$((fail+1))
  fi
}

echo "=============================================="
echo " 项目 F · 安全加固验收  $(date '+%F %T')"
echo "=============================================="

echo
echo "========== 一、RBAC（身份与权限）=========="

echo "[1] 容器内不应存在 API token（最小权限的极致）"
if [ -n "$POD" ]; then
  r=$(kubectl -n "$NS" exec "$POD" -- sh -c \
        'test -f /var/run/secrets/kubernetes.io/serviceaccount/token && echo EXIST || echo ABSENT' 2>/dev/null)
  chk "容器内 token 已移除" "ABSENT" "${r:-UNKNOWN}"
else
  echo "  ⚠️  找不到 damo-app Pod，跳过该项"
  fail=$((fail+1))
fi

echo "[2] 发布者 SA 的权限边界"
chk "可更新 damo-app 的 Deployment" "yes" "$(kubectl auth can-i update deployments -n $NS --as=$DEPLOYER 2>/dev/null)"
chk "可读取 damo-app 的 Secret（Helm 台账）" "yes" "$(kubectl auth can-i get secrets -n $NS --as=$DEPLOYER 2>/dev/null)"
chk "不可操作 monitoring 命名空间" "no" "$(kubectl auth can-i get deployments -n monitoring --as=$DEPLOYER 2>/dev/null)"
chk "不可读取全集群 Secret" "no" "$(kubectl auth can-i get secrets -A --as=$DEPLOYER 2>/dev/null)"
chk "不可删除节点" "no" "$(kubectl auth can-i delete nodes --as=$DEPLOYER 2>/dev/null)"
chk "不可创建命名空间" "no" "$(kubectl auth can-i create namespaces --as=$DEPLOYER 2>/dev/null)"
chk "不是万能（'*' '*'）" "no" "$(kubectl auth can-i '*' '*' --as=$DEPLOYER 2>/dev/null)"

echo "[3] 应用 Pod 用的是专用 SA（不是 default）"
sa=$(kubectl -n "$NS" get deploy damo-app -o jsonpath='{.spec.template.spec.serviceAccountName}' 2>/dev/null)
chk "serviceAccountName = damo-app-sa" "damo-app-sa" "${sa:-EMPTY}"

echo
echo "========== 二、NetworkPolicy（策略存在性）=========="

n=$(kubectl -n "$NS" get netpol --no-headers 2>/dev/null | wc -l | tr -d ' ')
echo "  当前策略条数：${n:-0}"
chk "至少 4 条策略" "4" "$([ "${n:-0}" -ge 4 ] && echo 4 || echo "${n:-0}")"

for name in default-deny-ingress default-deny-egress allow-damo-app-ingress allow-egress-dns; do
  if kubectl -n "$NS" get netpol "$name" >/dev/null 2>&1; then
    echo "  ✅ 存在策略 $name"
    pass=$((pass+1))
  else
    echo "  ❌ 缺少策略 $name"
    fail=$((fail+1))
  fi
done

echo "  检查 default-deny 没有误写成 ingress/egress: [{}]（那会变成全通）"
d1=$(kubectl -n "$NS" get netpol default-deny-ingress -o jsonpath='{.spec.ingress}' 2>/dev/null)
chk "default-deny-ingress 无 ingress 规则" "" "${d1}"
d2=$(kubectl -n "$NS" get netpol default-deny-egress -o jsonpath='{.spec.egress}' 2>/dev/null)
chk "default-deny-egress 无 egress 规则" "" "${d2}"

echo
echo "========== 三、业务可用性（放行是否够用）=========="

code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$APP_URL" 2>/dev/null)
chk "外部访问返回 200" "200" "${code:-000}"

want=$(kubectl -n "$NS" get deploy damo-app -o jsonpath='{.spec.replicas}' 2>/dev/null)
ready=$(kubectl -n "$NS" get deploy damo-app -o jsonpath='{.status.readyReplicas}' 2>/dev/null)
chk "副本全部 Ready" "${want:-x}" "${ready:-0}"

ep=$(kubectl -n "$NS" get endpoints damo-app -o jsonpath='{.subsets[0].addresses[*].ip}' 2>/dev/null | wc -w | tr -d ' ')
chk "Endpoints 有条目（Service 有后端）" "yes" "$([ "${ep:-0}" -ge 1 ] && echo yes || echo no)"

restarts=$(kubectl -n "$NS" get pods -l app.kubernetes.io/name=damo-app \
             -o jsonpath='{.items[*].status.containerStatuses[*].restartCount}' 2>/dev/null)
echo "  当前 Pod 重启次数：${restarts:-0}（应为 0 或不再增长）"

echo
echo "========== 四、网络边界（是否真的拒了不该通的）=========="

echo "[1] 跨命名空间：从 default 访问 damo-app（应被拒）"
r=$(kubectl -n default run "netchk-$RANDOM" --rm -i --restart=Never --quiet \
      --image="$BUSYBOX" -- \
      sh -c 'wget -qO- --timeout=3 http://damo-app.damo-app.svc.cluster.local/ >/dev/null 2>&1 && echo OPEN || echo BLOCKED' \
      2>/dev/null | tail -1)
chk "跨命名空间被拒" "BLOCKED" "${r:-UNKNOWN}"

echo "[2] 外网出方向：从业务 Pod 访问公网（应被拒，防数据外传）"
if [ -n "$POD" ]; then
  r=$(kubectl -n "$NS" exec "$POD" -- sh -c \
        'wget -qO- --timeout=3 http://www.baidu.com >/dev/null 2>&1 && echo OPEN || echo BLOCKED' 2>/dev/null)
  chk "外网出方向被拒" "BLOCKED" "${r:-UNKNOWN}"
fi

echo "[3] DNS 出方向：应放行（否则 Service 域名解析不了）"
if [ -n "$POD" ]; then
  r=$(kubectl -n "$NS" exec "$POD" -- sh -c \
        'nslookup damo-app.damo-app.svc.cluster.local >/dev/null 2>&1 && echo OK || echo FAIL' 2>/dev/null)
  chk "DNS 解析正常" "OK" "${r:-UNKNOWN}"
fi

echo
echo "=============================================="
echo " 结果：$pass 项通过，$fail 项失败"
if [ "$fail" -eq 0 ]; then
  echo " 🎉 安全加固验收全部通过"
else
  echo " ⚠️  有 $fail 项未通过，见上方 ❌"
  echo "     排错提示：先看《K8s项目F_安全加固实战.md》第 8 节故障速查表"
fi
echo "=============================================="

# 退出码：全部通过时为 0，便于接入 CI
[ "$fail" -eq 0 ] || exit 1
