#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check-groovy-braces.py —— Jenkinsfile / Groovy 脚本的「花括号配平」检查器

为什么需要它：
    Jenkinsfile 是 Groovy 代码，但**本地没法编译它** ——
    唯一的真实编译检查就是触发一次 Jenkins。
    一旦括号不配平，构建会在最开头就失败：
        WorkflowScript: 130: expecting '}', found '' @ line 130, column 1.
        org.codehaus.groovy.control.MultipleCompilationErrorsException
    所以**改完 Jenkinsfile，本地至少要跑一次这个脚本**。

它做什么：
    · 逐字符追踪 `{` / `}` 的嵌套深度
    · 正确跳过 `\"\"\"` 三引号字符串块与 `//` 行注释（避免字符串里的
      JSONPath `{...}` 之类干扰判断）
    · 深度出现负数时立刻报警（说明多了一个 `}`）
    · 结束时深度不为 0 就报错，并**指出最可能出问题的结构行**（深度与预期不符的行）

用法：
    python check-groovy-braces.py <Jenkinsfile> [更多文件...]
    # 配平 → 退出码 0；不配平 → 退出码 1（可用于 CI 前置检查）

实测案例（项目 F，2026-09-24）：
    仓库里的 Jenkinsfile 缺了关闭 `stages` 的右花括号 →
    最终深度 = 1 → 补在 `post` 之前即可。
    ★ 该缺陷在原版（加固改动之前）就已存在。
"""

import sys


def analyze(path):
    """返回 (最终深度, 报错行列表, 字符串块是否正常闭合, 结构行列表)"""
    try:
        src = open(path, encoding="utf-8").read()
    except Exception as e:                      # noqa: BLE001
        return None, [], False, [], f"无法读取：{e}"

    depth = 0
    line = 1
    i = 0
    n = len(src)
    in_triple = False
    in_line_comment = False
    problems = []
    structure = []          # (行号, 该行结束后的深度, 行文本)

    while i < n:
        # 行注释：一直到行尾
        if in_line_comment:
            if src[i] == "\n":
                in_line_comment = False
                line += 1
            i += 1
            continue

        # 三引号字符串块的开关
        if src.startswith('"""', i):
            in_triple = not in_triple
            i += 3
            continue

        ch = src[i]

        if ch == "\n":
            line += 1
            i += 1
            continue

        if not in_triple:
            if src.startswith("//", i):
                in_line_comment = True
                i += 2
                continue
            if ch == "{":
                depth += 1
                structure.append((line, depth, src.split("\n")[line - 1]))
            elif ch == "}":
                depth -= 1
                structure.append((line, depth, src.split("\n")[line - 1]))
                if depth < 0:
                    problems.append((line, "深度变成负数 —— 多了一个右花括号"))
                    depth = 0
        i += 1

    if in_triple:
        problems.append((line, '文件结束时仍停留在 """ 字符串块内 —— 三引号没配对'))

    return depth, problems, not in_triple, structure, None


def main(argv):
    files = argv[1:]
    if not files:
        print(__doc__)
        return 2

    bad = 0
    for path in files:
        depth, problems, triple_ok, structure, err = analyze(path)
        print(f"── {path}")
        if err:
            print(f"   ❌ {err}")
            bad += 1
            continue

        # 打印最后几个结构行，便于人工核对
        print("   最后 6 个结构行（行号 / 该行结束后深度）：")
        for ln, d, text in structure[-6:]:
            print(f"     {ln:>4}  深度={d:<3} | {text.strip()[:90]}")

        if problems:
            for ln, msg in problems:
                print(f"   ❌ 第 {ln} 行：{msg}")
            bad += 1
        if depth != 0:
            hint = "少了右花括号" if depth > 0 else "多了右花括号"
            print(f"   ❌ 最终嵌套深度 = {depth} （{hint} {abs(depth)} 个）")
            print("      排查思路：找【深度与预期不符】的那一行 ——")
            print("      例如 `post`、`stages` 这类块级关键字，")
            print("      它们应当出现在父块的深度上；深度 +1 就说明它被解析成了子块。")
            bad += 1
        elif not problems:
            print("   ✅ 花括号配平")
        print()

    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
