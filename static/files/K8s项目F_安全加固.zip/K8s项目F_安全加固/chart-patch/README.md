# 项目 F · chart-patch 使用说明

本目录是**项目 F（安全加固）对 damo-app Chart 的全部改动**。
项目 E 的 `damo-app-chart/` 保持它自己的原始形态，**不回写**。

---

## 一、文件清单与放置位置

| 本目录文件 | → 放到 chart 的哪里 | 作用 |
|---|---|---|
| `values.yaml` | `<chart目录>/values.yaml`（**覆盖**） | 完整参数来源：项目 E 原值 + 项目 F 的五项新增 |
| `values-prod.yaml` | `<chart目录>/values-prod.yaml`（**新增**） | 生产开关：把 `networkPolicy.enabled: true` 固化进 git |
| `deployment.yaml` | `<chart目录>/templates/deployment.yaml`（**覆盖**） | 三探针 `timeoutSeconds` + 专用 SA + 不挂 token + 容器 `securityContext` |
| `service.yaml` | `<chart目录>/templates/service.yaml`（**覆盖**） | `externalTrafficPolicy: Local` 条件渲染 |
| `networkpolicy.yaml` | `<chart目录>/templates/networkpolicy.yaml`（**新增**） | 5 条 NetworkPolicy |
| `serviceaccount.yaml` | `<chart目录>/templates/serviceaccount.yaml`（**新增**） | 专用 SA（不绑 Role） |
| `Jenkinsfile` | `<仓库根>/Jenkinsfile`（**覆盖**） | Stage 4 加 `-f chart/damo-app/values-prod.yaml`（让流水线带上加固） |
| `push-to-repo.sh` | — | ★ **一键提交到 GitHub 的脚本**（见第六节） |
| `values-fragment.yaml` | — | **旧版片段，已被 `values.yaml` 取代**，保留仅作参考 |

**项目 F 对 chart 的 5 项改动**（对应阶段 3 / 4.3 / 4.4 / 4 / 5）：

| # | 改动 | 在 values 里的位置 | 阶段 |
|---|---|---|---|
| 1 | 专用 SA + `automountServiceAccountToken: false` | `serviceAccount` 段 | 3 |
| 2 | `probes.timeoutSeconds: 1`（显式化 API 默认值） | `probes` 段 | 4.3 |
| 3 | `service.externalTrafficPolicy: Local`（规则① 的前置条件） | `service` 段 | 4.4 |
| 4 | `networkPolicy` 段（含 `egress`） | `networkPolicy` 段 | 4 |
| 5 | `securityContext`（禁提权 + drop ALL + seccomp） | `securityContext` 段 | 5 |

> ⚠️ **第 5 项有个坑，而且不是网上常说的那个**：
> 实测（2026-09-24）**纯 `drop: ["ALL"]` 会让 nginx 起不来**，报
> `nginx: [emerg] chown("/var/cache/nginx/client_temp", 101) failed (1: Operation not permitted)`
> —— 需要的是 **`CAP_CHOWN`**（nginx master 以 root 启动时要把缓存目录 chown 给 worker 用户），
> **不是** `NET_BIND_SERVICE`（我一开始也猜错了，对照组实测把它否掉了）。
> 另外还需 **`SETGID` / `SETUID`** 才能降权起 worker。
> 所以 values.yaml 里已按实测结果 `add` 回那 4 个：
> `["CHOWN", "NET_BIND_SERVICE", "SETGID", "SETUID"]`。
> **最小权限不是"什么都不给"，而是"只给必需的那一个"—— 而"必需的那一个"必须实测，不能猜。**

> 注：`networkpolicy.yaml` 与 `serviceaccount.yaml` 在项目 F 的阶段 3/4 就已经是"要并进 Chart 的文件"，
> 现按同目录约定补齐（凡是 `templates/` 下的模板，都直接放在本目录根下）。

---

## 二、部署（复制粘贴即可）

```bash
cd ~/F/chart-patch                  # 假设本目录已传到 master 的这个路径
CHART=~/damo-app-chart

# ① 覆盖/拷入（一次搞定）
cp values.yaml       $CHART/values.yaml
cp values-prod.yaml  $CHART/values-prod.yaml
cp deployment.yaml   $CHART/templates/deployment.yaml
cp service.yaml      $CHART/templates/service.yaml
cp networkpolicy.yaml  $CHART/templates/networkpolicy.yaml
cp serviceaccount.yaml $CHART/templates/serviceaccount.yaml

# ② ★ 动手前必须确认：专用 SA 必须存在，否则 Pod 会创建失败
kubectl -n damo-app get sa | grep damo-app-sa
# 没有的话，第 ① 步里的 serviceaccount.yaml 会把它建出来；
# 但如果你的 chart 里已有同名 SA 模板，跳过那一条即可。

# ③ 自检（先确认"东西都在"，再升级）
grep -c "kind: NetworkPolicy" $CHART/templates/networkpolicy.yaml   # 期望 5
grep -c "timeoutSeconds"      $CHART/templates/deployment.yaml      # 期望 3
grep -c "serviceAccountName"  $CHART/templates/deployment.yaml      # 期望 1
grep -c "externalTrafficPolicy" $CHART/templates/service.yaml $CHART/values.yaml   # 期望各 1

# ④ 干跑看渲染（--set 只为干跑；正式升级用 -f）
helm template damo-app $CHART -n damo-app -f $CHART/values-prod.yaml \
  | grep -c "kind: NetworkPolicy"                                   # 期望 5

# ⑤ 正式升级（★ 用 -f，不用 --set）
helm upgrade damo-app $CHART -n damo-app \
  -f $CHART/values-prod.yaml --atomic --timeout 3m
```

---

## 三、验收

```bash
kubectl -n damo-app get netpol                                    # damo-app-* 共 5 条
kubectl -n damo-app get svc damo-app -o jsonpath='{.spec.externalTrafficPolicy}{"\n"}'   # Local
kubectl -n damo-app get pods -l app.kubernetes.io/name=damo-app   # 2 个 1/1 Running
kubectl -n damo-app get deploy damo-app -o jsonpath='{.spec.template.spec.serviceAccountName}{" / "}{.spec.template.spec.automountServiceAccountToken}{"\n"}'
# 期望：damo-app-sa / false

# ★★ 证明"加固真的固化了"（不是靠 --set 临时给的）
helm get values damo-app -n damo-app --all | grep -E "externalTrafficPolicy|enabled"
# 期望两项都在

# 功能四关
NODE=$(kubectl -n damo-app get pods -l app.kubernetes.io/name=damo-app \
        -o jsonpath='{.items[0].status.hostIP}')
curl --noproxy '*' -s --max-time 5 "http://$NODE:30090/" | grep -o 'Build #[0-9]*'       # Build #N
kubectl -n damo-app exec deploy/loadgen -- sh -c '
  wget -qO- --timeout=5 http://damo-app.damo-app.svc.cluster.local/ 2>&1 | head -2'       # <!DOCTYPE html>
```

---

## 四、一键回退

```bash
# 关掉加固开关（保留 Chart，只是不渲染 NetworkPolicy）
helm upgrade damo-app $CHART -n damo-app --set networkPolicy.enabled=false --atomic

# 或整体回滚上一个 revision
helm rollback damo-app -n damo-app

# 或把项目 E 的原始文件恢复回去（从项目 E 目录重新拷）
```

---

## 五、为什么不回写项目 E

- **项目 E 是"Helm 化改造"的独立作品** —— 它当时的形态（探针没有 `timeoutSeconds`、
  Service 用默认的 `Cluster` 策略）是它自己的历史状态，不应被后续项目覆盖。
- **项目 F 是"安全加固"** —— 它的产物（改过哪些值、加了哪些模板、为什么这么加）
  全部收敛在本目录，**自包含、可单独审阅**。
- 两个项目各自的文档与交付物都能对得上，不会互相污染。

---

## 六、提交到 GitHub 仓库（★ 一键脚本）

### 为什么需要这一步 —— 而且它比想象中紧急

仓库 `GXEL-xy/damo-app` 的 `chart/damo-app/` 此前**停留在项目 E 原版**，
而 **Jenkinsfile 的 Stage 4 直接发布它**：

```groovy
helm upgrade --install damo-app chart/damo-app --set image.tag=${IMAGE_TAG} --atomic
```

**⟹ 下一次流水线发布会：**
1. 用**未加固**的 chart 渲染；
2. Helm 会**删除**上一次 manifest 里有、这次没有的资源 → **5 条 NetworkPolicy 全被删**；
3. `externalTrafficPolicy: Local` 被重置回 `Cluster` → **规则① 失效、外部访问断**；
4. SA / `securityContext` 加固消失；
5. **而且不会报错**（Pod 照常起，只是回到裸奔）—— `--atomic` 也救不了，因为"没失败"。

**这就是"加固被流水线静默冲掉"。** 所以必须把加固后的 chart + 改过的 Jenkinsfile 提交上去。

### 怎么提交

```bash
cd <本目录>
bash push-to-repo.sh        # 克隆 → 覆盖 7 个文件 → 自检 → 确认 → 推送
```

脚本会覆盖这 **7 个文件**（仓库里的 `index.html` / `Dockerfile` / `k8s/` 等不动）：

| 本目录文件 | → 仓库路径 |
|---|---|
| `values.yaml` | `chart/damo-app/values.yaml` |
| `values-prod.yaml` | `chart/damo-app/values-prod.yaml` |
| `deployment.yaml` | `chart/damo-app/templates/deployment.yaml` |
| `service.yaml` | `chart/damo-app/templates/service.yaml` |
| `networkpolicy.yaml` | `chart/damo-app/templates/networkpolicy.yaml` |
| `serviceaccount.yaml` | `chart/damo-app/templates/serviceaccount.yaml` |
| `Jenkinsfile` | `Jenkinsfile`（仓库根） |

> 脚本里用 `REPO=` / `BRANCH=` 环境变量可以覆盖默认值：
> `REPO=git@github.com:GXEL-xy/damo-app.git bash push-to-repo.sh`

### 提交完怎么验证

1. **在 master 上拉一次**（`git pull`），或直接触发一次 Jenkins 发布；
2. 看 **Stage 5 的输出**（已在 Jenkinsfile 里新增了加固验证项）：
   ```
   kubectl get netpol -n damo-app                    # 期望仍是 5 条 damo-app-*
   kubectl get svc damo-app -n damo-app -o jsonpath='{.spec.externalTrafficPolicy}'   # 期望 Local
   ```
3. 本地干跑一次确认渲染无误：
   ```bash
   helm template damo-app chart/damo-app -f chart/damo-app/values-prod.yaml \
     | grep -c "kind: NetworkPolicy"                 # 期望 5
   ```

> ⚠️ **顺序提醒**：`securityContext` 的 `capabilities.drop: [ALL]` **还没在集群上实测过**。
> 建议**先手动跑一次** `helm upgrade -f values-prod.yaml` 确认 nginx 能起
> （必要时加回 `NET_BIND_SERVICE`），**再让流水线跑** ——
> 否则流水线会因为 Pod 起不来而失败回滚（有 `--atomic` 保护，不会坏，只是白跑一次）。
