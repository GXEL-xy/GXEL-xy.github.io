#!/usr/bin/env bash
# ============================================================
# 项目 F · 一键把「加固后的 Chart + Jenkinsfile」提交到 GXEL-xy/damo-app
#
# 为什么需要这个脚本：
#   AI 侧的 GitHub 连接器目前只有【读】权限（写会返回 403
#   Resource not accessible by integration），所以由你用自己的凭据提交。
#
# 用法（在能访问 GitHub 的机器上执行）：
#   cd <本目录>
#   bash push-to-repo.sh
#
# 它会：克隆仓库 → 覆盖 7 个文件 → 提交 → 推送
# 只覆盖这 7 个文件，仓库里的其它文件（index.html / Dockerfile / k8s/ …）不动。
# ============================================================
set -euo pipefail

REPO="${REPO:-https://github.com/GXEL-xy/damo-app.git}"
BRANCH="${BRANCH:-main}"

SRC="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)/damo-app"

echo "==> 仓库: $REPO  (branch: $BRANCH)"
echo "==> 克隆到: $WORK"
git clone --depth 1 --branch "$BRANCH" "$REPO" "$WORK"

echo "==> 覆盖 chart 文件"
cp "$SRC/values.yaml"         "$WORK/chart/damo-app/values.yaml"
cp "$SRC/values-prod.yaml"    "$WORK/chart/damo-app/values-prod.yaml"
cp "$SRC/deployment.yaml"     "$WORK/chart/damo-app/templates/deployment.yaml"
cp "$SRC/service.yaml"        "$WORK/chart/damo-app/templates/service.yaml"
cp "$SRC/networkpolicy.yaml"  "$WORK/chart/damo-app/templates/networkpolicy.yaml"
cp "$SRC/serviceaccount.yaml" "$WORK/chart/damo-app/templates/serviceaccount.yaml"

echo "==> 覆盖 Jenkinsfile（Stage 4 已加 -f chart/damo-app/values-prod.yaml）"
cp "$SRC/Jenkinsfile"         "$WORK/Jenkinsfile"

cd "$WORK"

echo
echo "==> 改动概览"
git status --short
echo

echo "==> 渲染自检（期望 5 条 NetworkPolicy）"
if command -v helm >/dev/null 2>&1; then
  helm template damo-app chart/damo-app -f chart/damo-app/values-prod.yaml \
    | grep -c "kind: NetworkPolicy" || true
else
  echo "（本机没装 helm，跳过；可稍后在 master 上跑）"
fi
echo

read -r -p "确认提交并推送？(y/N) " ans
case "$ans" in
  y|Y) ;;
  *) echo "已取消。临时目录保留在：$WORK"; exit 0 ;;
esac

git add -A
git commit -F - <<'MSG'
feat(安全加固): 把 NetworkPolicy / SA / securityContext 固化进 Chart，并让流水线带上生产 values

背景：仓库 chart 此前停留在项目 E 原版，而 Jenkinsfile Stage 4 直接发布它
(`helm upgrade --install damo-app chart/damo-app --set image.tag=N`)。
下一次流水线发布会用未加固的 chart 渲染，Helm 会【删除】上一次发布创建的
5 条 NetworkPolicy、把 externalTrafficPolicy 重置回 Cluster、丢掉 SA 与
securityContext —— 而且不会报错（Pod 照常起，只是回到裸奔），
即"加固被流水线静默冲掉"。

本次改动：
- chart/damo-app/values.yaml: 新增 service.externalTrafficPolicy=Local、
  probes.timeoutSeconds、serviceAccount、networkPolicy(含 egress)、securityContext
- chart/damo-app/values-prod.yaml: 新增；把 networkPolicy.enabled=true 等生产配置固化在 git
- chart/damo-app/templates/deployment.yaml: 三探针 timeoutSeconds + 专用 SA + automount=false + securityContext
- chart/damo-app/templates/service.yaml: externalTrafficPolicy 条件渲染
- chart/damo-app/templates/networkpolicy.yaml: 新增；5 条策略(2 全拒 + 3 白名单)
- chart/damo-app/templates/serviceaccount.yaml: 新增；专用 SA(不绑 Role、automount=false)
- Jenkinsfile: Stage 4 增加 -f chart/damo-app/values-prod.yaml；
  Stage 5 增加"加固是否还在"的验证(列出 netpol 与 externalTrafficPolicy)

依据：项目 F 实战文档 §4.4(抓包定位 NodePort 源 IP 被 MASQUERADE)、
§4.7(政策即代码)、§4.7.5(--set 不算固化)、§5.2(容器安全上下文)

注意：securityContext 的 capabilities.drop=[ALL] 需先手动验证 nginx 绑 80 端口
不受影响（必要时加回 NET_BIND_SERVICE）；--atomic 保证失败自动回滚。
MSG

echo "==> 推送"
git push origin "$BRANCH"

echo
echo "✅ 完成。"
echo "   建议下一步：在 master 上拉一次 / 或直接触发一次 Jenkins 发布，"
echo "   然后在 Stage 5 的输出里确认 netpol 仍是 5 条、externalTrafficPolicy 仍是 Local。"
