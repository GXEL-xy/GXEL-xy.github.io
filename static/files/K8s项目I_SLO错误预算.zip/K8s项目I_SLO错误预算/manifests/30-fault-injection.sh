#!/usr/bin/env bash
# ============================================================
# 项目 I 故障演练：制造可控的 5xx，验证 SLO 燃烧率告警
#
# 用法（在能访问集群的机器上）：
#   bash 30-fault-injection.sh fast    # 快烧：100% 失败持续 180 秒
#   bash 30-fault-injection.sh slow    # 对照：同样失败，只持续 30 秒
#
# 原理：把 damo-app 缩到 0 副本，ingress-nginx 找不到 ready endpoint
#       会给所有请求返回 503 —— 这是真实用户视角的失败，会直接进 SLI。
# ============================================================
set -uo pipefail

NS="${NS:-damo-app}"
DEPLOY="${DEPLOY:-damo-app}"
SCENARIO="${1:-fast}"

ORIG=$(kubectl -n "$NS" get deploy "$DEPLOY" -o jsonpath='{.spec.replicas}' 2>/dev/null)
if [ -z "$ORIG" ]; then
  echo "找不到 Deployment $NS/$DEPLOY，请先确认命名空间和名字"
  exit 1
fi

echo "=============================================="
echo " 目标：$NS/$DEPLOY   当前副本：$ORIG"
echo "=============================================="

countdown() {
  local total=$1
  while [ "$total" -gt 0 ]; do
    printf "\r  剩余 %3ds ..." "$total"
    sleep 5
    total=$((total - 5))
  done
  printf "\r  故障注入结束      \n"
}

restore() {
  kubectl -n "$NS" scale deploy "$DEPLOY" --replicas="$ORIG" >/dev/null
  echo "已恢复副本数到 $ORIG"
}

case "$SCENARIO" in
  fast)
    echo "场景 A：快烧 —— 100% 失败持续 300 秒"
    echo "（为什么是 5 分钟：1h 窗口要被稀释到燃烧率 >14.4x，至少需要 4.32 分钟的全量失败）"
    kubectl -n "$NS" scale deploy "$DEPLOY" --replicas=0
    countdown 300
    restore
    cat <<'TIP'

观察点（按顺序）：
  1. 30 秒内  Grafana「请求速率(按状态码)」的 503 面积顶满
  2. 1 分钟内  「当前成功率 SLI」掉到 0%，5m 燃烧率瞬间到 200x
  3. 4~5 分钟  1h 燃烧率才爬过 14.4x —— 这是短窗口先动、长窗口后动的正常现象
  4. 再等 2 分钟 for 条件满足，Alertmanager 出现 SLOBurnRateFast（critical）
TIP
    ;;
  slow)
    echo "场景 B：对照 —— 同样 100% 失败，只持续 30 秒"
    kubectl -n "$NS" scale deploy "$DEPLOY" --replicas=0
    countdown 30
    restore
    cat <<'TIP'

观察点：
  1. 5m 燃烧率会瞬间飙高（瞬时值很吓人）
  2. 但 1h 燃烧率几乎不动：30 秒 / 3600 秒 ≈ 0.8%，换算后约 1.2x
  3. 结果：没有任何 SLO 告警 firing

这就是「多窗口」的意义：短抖动不会叫醒人，持续恶化才会。
如果只看 5m 单窗口，这 30 秒就会触发一条误报。
TIP
    ;;
  *)
    echo "用法：$0 [fast|slow]"
    exit 1
    ;;
esac
