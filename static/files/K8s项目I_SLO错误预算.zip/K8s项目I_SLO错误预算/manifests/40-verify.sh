#!/usr/bin/env bash
# ============================================================
# 项目 I 验收脚本：五个关卡，全过才算 SLO 链路打通
# 用法：bash 40-verify.sh
# ============================================================
set -uo pipefail

NS="${NS:-monitoring}"
SVC="${SVC:-prometheus}"
PORT="${PORT:-19090}"

pass=0; fail=0
ok()   { echo "  [PASS] $1"; pass=$((pass+1)); }
bad()  { echo "  [FAIL] $1"; fail=$((fail+1)); }

echo "== 启动 port-forward $NS/$SVC -> 127.0.0.1:$PORT"
kubectl -n "$NS" port-forward "svc/$SVC" "$PORT:9090" >/dev/null 2>&1 &
PF=$!
trap 'kill $PF 2>/dev/null' EXIT
sleep 3

q() { curl -s --max-time 8 --data-urlencode "query=$1" "http://127.0.0.1:$PORT/api/v1/query"; }

echo
echo "== 关卡 1：ingress-nginx 是否被抓到"
r=$(q 'up{job="ingress-nginx"}')
if echo "$r" | grep -q '"value"'; then
  echo "$r" | grep -o '"1"' >/dev/null && ok "ingress-nginx 抓取正常" || bad "抓到了但 up != 1（看 target 报错）"
else
  bad "没有 up{job=\"ingress-nginx\"} 的数据 —— 检查 metrics Service 与 relabel 规则"
fi

echo
echo "== 关卡 2：原始 SLI 指标是否存在"
r=$(q 'sum(rate(nginx_ingress_controller_requests{namespace="damo-app"}[5m]))')
echo "$r" | grep -q '"value"' && ok "ingress-nginx 请求指标有数据" || bad "没有请求指标（业务无流量？或 namespace 标签不对）"

echo
echo "== 关卡 3：记录规则是否产出"
for m in slo:sli_ratio:5m slo:burn_rate:1h slo:budget:remaining_ratio; do
  r=$(q "$m")
  echo "$r" | grep -q '"value"' && ok "记录规则 $m 有值" || bad "记录规则 $m 无值（规则未加载或还没到评估周期）"
done

echo
echo "== 关卡 4：告警规则是否已加载"
r=$(curl -s --max-time 8 "http://127.0.0.1:$PORT/api/v1/rules?type=alert")
for a in SLOBurnRateFast SLOBurnRateMedium SLOBurnRateSlow SLOBudgetLow SLONoData; do
  echo "$r" | grep -q "\"$a\"" && ok "告警规则 $a 已加载" || bad "告警规则 $a 未加载"
done

echo
echo "== 关卡 5：当前 SLI 快照"
v=$(q 'slo:sli_ratio:5m')
echo "  $v" | head -c 300; echo

echo
echo "=============================================="
echo " PASS: $pass    FAIL: $fail"
[ "$fail" -eq 0 ] && echo " 结论：SLO 链路完整，可以做演练了" || echo " 结论：先修 FAIL 项，再看文档第 2/3 阶段"
echo "=============================================="
