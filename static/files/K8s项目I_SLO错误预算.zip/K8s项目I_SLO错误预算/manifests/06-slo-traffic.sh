#!/usr/bin/env bash
# ============================================================
# 项目 I 流量发生器：让请求「经过 ingress-nginx」，SLI 才有数据
#
# 为什么不用 loadgen：G 项目的 loadgen 在集群内直连 Service，
# 流量不经过七层入口，ingress-nginx 统计不到 —— SLO 会一直是空的。
#
# 为什么放在 default 命名空间：F 项目给 damo-app 做了 egress 默认拒绝，
# 在 damo-app 里发起的出站请求会被静默丢包（表现为 timed out，不是 refused）。
# 而且语义上「外部用户」本来就不该待在业务命名空间里。
#
# 用法：
#   bash 06-slo-traffic.sh              # 默认 0.2s 一次，约 5 req/s
#   INTERVAL=0.05 bash 06-slo-traffic.sh   # 加大压力
#   kubectl -n default delete pod slo-traffic     # 停止
# ============================================================
set -uo pipefail

NS="${NS:-default}"
HOST_HEADER="${HOST_HEADER:-damo.example.com}"
INGRESS_SVC="${INGRESS_SVC:-ingress-nginx-controller.ingress-nginx.svc.cluster.local}"
INTERVAL="${INTERVAL:-0.2}"

echo "=============================================="
echo " Host    : $HOST_HEADER"
echo " 目标    : http://$INGRESS_SVC/"
echo " 间隔    : ${INTERVAL}s"
echo "=============================================="

kubectl -n "$NS" delete pod slo-traffic --ignore-not-found >/dev/null 2>&1

kubectl -n "$NS" run slo-traffic \
  --image=busybox:1.36 --restart=Never --command -- \
  sh -c "while true; do wget -q -O /dev/null --header='Host: $HOST_HEADER' http://$INGRESS_SVC/ 2>/dev/null || true; sleep $INTERVAL; done" >/dev/null

sleep 4
kubectl -n "$NS" get pod slo-traffic

cat <<'TIP'

接下来验证流量是否真的进了 ingress-nginx（约 1 分钟后有值）：

  kubectl -n monitoring port-forward svc/prometheus 9090:9090 >/dev/null 2>&1 &
  curl -s --data-urlencode 'query=sum(rate(nginx_ingress_controller_requests{namespace="damo-app"}[5m]))' \
       http://127.0.0.1:9090/api/v1/query

如果返回 0：
  - 检查流量 Pod 的日志：kubectl -n damo-app logs slo-traffic
  - 检查 Ingress 是否生效：curl -H "Host: damo.example.com" -o /dev/null -w '%{http_code}\n' http://11.0.1.128:32541/
TIP
