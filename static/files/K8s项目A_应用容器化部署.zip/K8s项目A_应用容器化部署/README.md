# K8s 项目 A：WordPress + MySQL 应用容器化部署 · 文件包

配套文章：<https://GXEL-xy.github.io/posts/k8s项目a_应用容器化部署实战/>

## 文件说明

编号是**逻辑编号**（按资源类型分组），不是部署顺序。

| 文件 | 内容 | 所属阶段 |
|---|---|---|
| `00-namespace.yaml` | 命名空间 `wordpress` | 阶段 2 |
| `02-secret.yaml` | MySQL / WordPress 数据库密码 | 阶段 2 |
| `03-storageclass.yaml` | StorageClass `fast-local`（集群已有默认 SC 可跳过） | 阶段 2 |
| `04-mysql-statefulset.yaml` | MySQL Headless Service + StatefulSet + `volumeClaimTemplates` | 阶段 2 |
| `01-configmap.yaml` | WordPress 非敏感配置（`WORDPRESS_DB_HOST` 等） | 阶段 3 |
| `05-wordpress-deployment.yaml` | WordPress Deployment，探针为 `tcpSocket`（定版） | 阶段 3 |
| `06-service.yaml` | WordPress ClusterIP Service | 阶段 3 |
| `07-ingress.yaml` | Ingress（`blog.example.com`） | 阶段 4 |

## 部署顺序

```bash
# 阶段 2：先起数据库
kubectl apply -f 00-namespace.yaml
kubectl apply -f 02-secret.yaml
kubectl apply -f 03-storageclass.yaml       # 已有默认 SC 可跳过
kubectl apply -f 04-mysql-statefulset.yaml

# 阶段 3：再起应用
kubectl apply -f 01-configmap.yaml
kubectl apply -f 05-wordpress-deployment.yaml
kubectl apply -f 06-service.yaml

# 阶段 4：对外暴露
kubectl apply -f 07-ingress.yaml
```

## 执行前提

- 集群已装 StorageClass（本项目用 `local-path`，清单里的 `fast-local` 需按实际改名）
- 已装 ingress-nginx（`helm install ingress-nginx ingress-nginx/ingress-nginx`）
- 节点能拉到 `mysql:8.0` 与 `wordpress:6.5` 镜像（内网环境走私有仓库中转）

## 注意

- `02-secret.yaml` 里是**练习环境的示例密码**，落到任何真实环境前必须替换；`stringData` 只是省去手动 base64，不是加密。
- `07-ingress.yaml` 的 `host` 要换成自己的域名，本地验证用 `/etc/hosts` 绑定节点 IP。
- 探针用 `tcpSocket` 而不是 `httpGet`，原因见文章「故障速查表」第 1、8 条：`httpGet` 的 `timeoutSeconds` 默认 1 秒，PHP 冷启动超过 1 秒就会被判失败、反复重启。

## 清理

```bash
kubectl delete -f . --ignore-not-found
kubectl delete pvc data-mysql-0 -n wordpress    # PVC 不随命名空间自动删除
```
